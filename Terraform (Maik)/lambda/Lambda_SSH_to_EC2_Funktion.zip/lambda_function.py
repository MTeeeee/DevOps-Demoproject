import boto3
import paramiko
import base64
import os

def lambda_handler(event, context):
    ssm_client = boto3.client('ssm')
    
    # Standard-Antwortobjekt erstellen
    response = {
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,GET,PUT,POST,DELETE,PATCH,HEAD',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent'
        }
    }
    
    try:
        # Hole den privaten Schlüssel aus dem Parameter Store
        private_key = ssm_client.get_parameter(
            Name='DevOps-Project-Key-Control-Node',
            WithDecryption=True
        )['Parameter']['Value']
        
        # Erstelle ein SSH-Client-Objekt
        key = paramiko.RSAKey.from_private_key_str(private_key)
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        # Verbindung zur EC2-Instanz herstellen
        client.connect(os.environ['EC2_INSTANCE_IP'], username='ec2-user', pkey=key)

        # Befehl ausführen, um eine Textdatei zu erstellen
        stdin, stdout, stderr = client.exec_command('echo "Hier ist mein Text" > /home/ec2-user/HelloFromLambda.txt')
        
        # Überprüfen, ob es Fehler in stderr gibt
        err = stderr.read().decode()
        if err:
            raise Exception(f"SSH command error: {err}")
        
        # Verbindung schließen
        client.close()
        
        response['statusCode'] = 200
        response['body'] = 'Textdatei wurde erfolgreich erstellt!'
        
    except Exception as e:
        response['statusCode'] = 500
        response['body'] = f"Ein Fehler ist aufgetreten: {str(e)}"
        
    return response
