import json

def lambda_handler(event, context):
    responseMsg = {
        'statusCode' : '200',
        'body': json.dumps('Hello from Lambda!'),
        'headers' : {
            'Access-Control-Allow-Origin' : '*'
        }
    }
    return responseMsg